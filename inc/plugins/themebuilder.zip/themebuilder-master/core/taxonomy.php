<?php 


/**
 * This function creates custom taxonomies. It has a filter hook.
 */

function themebuilder_register_taxonomy(){
	$args = array();
	$taxonomies = apply_filters('themebuilder_taxonomies', $args);
	foreach ($taxonomies as $taxonomy) {
		register_taxonomy($taxonomy['taxonomy'], $taxonomy['post_types'], $taxonomy['args']);
	}
}

add_action('init', 'themebuilder_register_taxonomy');

?>
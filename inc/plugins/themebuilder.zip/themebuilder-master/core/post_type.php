<?php
/**
 * Created by PhpStorm.
 * User: aqibashef
 * Date: 5/6/17
 * Time: 10:31 PM
 */

/**
 * This function creates post types. It has a filter hook
 */

function themebuilder_register_post_type(){
    $args = array();
    $post_types = apply_filters('themebuilder_post_types', $args);
    foreach ($post_types as $post_type){
        register_post_type($post_type['post_type'], $post_type['args']);
    }
}
add_action('init', 'themebuilder_register_post_type');

?>
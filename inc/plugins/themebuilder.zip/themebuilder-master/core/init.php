<?php
/**
 * Created by PhpStorm.
 * User: aqibashef
 * Date: 5/6/17
 * Time: 10:41 PM
 */

$files = glob(plugin_dir_path(__FILE__) . '*.php');
foreach ($files as $filename) {
	if(!preg_match('/init.php/', $filename)){
		require_once $filename;
	}
}

?>
<?php
/**
 * Created by PhpStorm.
 * User: aqibashef
 * Date: 5/6/17
 * Time: 10:41 PM
 */

require_once plugin_dir_path(__FILE__).'/post_type.php';

?>
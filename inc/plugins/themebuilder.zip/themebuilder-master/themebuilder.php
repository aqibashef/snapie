<?php
/*
Plugin Name: Theme Builder
Plugin URI: http://aqibashef.me/themebuilder
Description: This plugin is developed to support theme developers around the globe.
Author: Aqib Ashef
Version: 1.0.0
Author URI: http://aqibashef.me
*/

require_once plugin_dir_path(__FILE__) . '/core/init.php';
require_once plugin_dir_path(__FILE__) . '/settings-page/init.php';

?>